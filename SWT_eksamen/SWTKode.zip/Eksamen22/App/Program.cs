﻿// See https://aka.ms/new-console-template for more information
using ClassLibrary.Boundry;
using ClassLibrary.Controllers;
using ClassLibrary.Interfaces;

Console.WriteLine("Hello, World!");

