global using NUnit.Framework;
global using ClassLibrary.Boundry;
global using ClassLibrary.Interfaces;
global using ClassLibrary.Controllers;