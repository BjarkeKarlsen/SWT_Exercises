namespace DoorControl
{
    public interface IUserValidation
    {
        bool ValidateEntryRequest(string id);
    }

}