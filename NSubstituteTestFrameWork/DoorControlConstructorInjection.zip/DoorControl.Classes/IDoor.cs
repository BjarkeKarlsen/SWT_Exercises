namespace DoorControl
{
    public interface IDoor
    {
        void Open();
        void Close();
    }

}