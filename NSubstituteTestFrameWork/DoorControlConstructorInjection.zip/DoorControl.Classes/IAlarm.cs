namespace DoorControl
{
    public interface IAlarm
    {
        void SoundAlarm();
    }

}


